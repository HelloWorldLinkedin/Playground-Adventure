import UIKit

var str = "Hello, playground"
var hp = 95;
let maxHP = 80;

hp = 90;

var notHelloWorld = "Hello World";

print(notHelloWorld)

//var inventoryInferred = 5       //Type Safe automatic variable type allocation, in this case INT
//var inventoryExplicited: Int    //assigning a variable type

var currentMP = 15
currentMP -= 5
print(currentMP)

